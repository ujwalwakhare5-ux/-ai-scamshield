const input = document.getElementById("messageInput");
const count = document.getElementById("charCount");
const result = document.getElementById("result");
const signalsList = document.getElementById("signalsList");

document.getElementById("year").textContent = new Date().getFullYear();

input.addEventListener("input", () => {
  count.textContent = `${input.value.length} characters`;
});

document.getElementById("clearBtn").addEventListener("click", () => {
  input.value = "";
  count.textContent = "0 characters";
  result.hidden = true;
  input.focus();
});

const rules = [
  { terms: ["urgent", "immediately", "act now", "within 24 hours", "today"], label: "Creates urgency or pressure to act quickly", points: 2 },
  { terms: ["otp", "one time password", "verification code", "pin"], label: "Mentions an OTP, PIN, or verification code", points: 3 },
  { terms: ["password", "login details", "account details", "bank details"], label: "Requests sensitive account or login information", points: 3 },
  { terms: ["click here", "verify your account", "update kyc", "account blocked"], label: "Asks you to verify details or threatens account access", points: 2 },
  { terms: ["won", "winner", "prize", "lottery", "free gift"], label: "Uses a prize, lottery, or free-gift claim", points: 2 },
  { terms: ["send money", "pay now", "processing fee", "transfer money"], label: "Requests money or an advance payment", points: 3 },
  { terms: ["gift card", "crypto", "bitcoin"], label: "Mentions an unusual payment method or cryptocurrency", points: 2 },
  { terms: ["http://", "bit.ly", "tinyurl.com", "t.co/"], label: "Contains a shortened or non-secure-looking link", points: 2 }
];

document.getElementById("analyzeBtn").addEventListener("click", () => {
  const message = input.value.trim().toLowerCase();
  if (!message) {
    input.focus();
    input.placeholder = "Please paste a message first so it can be checked.";
    return;
  }

  const matches = rules.filter(rule => rule.terms.some(term => message.includes(term)));
  const rawScore = matches.reduce((total, rule) => total + rule.points, 0);
  const score = Math.min(100, Math.round((rawScore / 12) * 100));
  let level, title, summary, advice, color;

  if (score >= 50) {
    level = "High warning"; title = "Several warning signs found"; color = "#d94a4a";
    summary = "This message contains multiple patterns commonly seen in scam attempts. Treat it with caution.";
    advice = "Do not click links, reply with private details, or send money. Contact the organisation using a phone number or website you find independently.";
  } else if (score >= 20) {
    level = "Be cautious"; title = "Some warning signs found"; color = "#d58a22";
    summary = "A few suspicious patterns were detected. Verify the sender and the request independently before taking action.";
    advice = "Pause before responding. Open the official app or website yourself, and never share an OTP, PIN, or password.";
  } else {
    level = "Low indicators"; title = "Few common warning signs found"; color = "#159b78";
    summary = "The demo did not find many of its known warning patterns. That does not prove the message is safe.";
    advice = "Check the sender address and website domain. If the message asks for money or sensitive details, verify through an official channel.";
  }

  document.getElementById("resultTitle").textContent = title;
  document.getElementById("riskPill").textContent = level;
  document.getElementById("riskPill").style.background = score >= 50 ? "#ffeded" : score >= 20 ? "#fff3df" : "#e8faf4";
  document.getElementById("riskPill").style.color = color;
  document.getElementById("resultSummary").textContent = summary;
  document.getElementById("meterFill").style.width = `${score}%`;
  document.getElementById("meterFill").style.background = color;
  document.getElementById("scoreLine").textContent = `Demo indicator score: ${score}/100 · Based only on the patterns checked`;
  signalsList.innerHTML = "";

  if (matches.length) {
    matches.forEach(match => {
      const li = document.createElement("li");
      li.textContent = match.label;
      signalsList.appendChild(li);
    });
  } else {
    const li = document.createElement("li");
    li.textContent = "No matching warning patterns found by this basic demo.";
    signalsList.appendChild(li);
  }

  document.getElementById("advice").textContent = advice;
  result.hidden = false;
  result.scrollIntoView({ behavior: "smooth", block: "nearest" });
});
