# AI ScamShield

A responsive cybersecurity awareness website starter project by Ujwal Vijay Wakhare.

## Files
- `index.html` — page structure
- `style.css` — responsive design
- `script.js` — browser-based suspicious-message pattern checker

## Run locally
Open `index.html` in a modern browser.

## Publish with GitHub Pages
1. Upload all three files to the root of your GitHub repository.
2. Open repository **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select branch **main** and folder **/(root)**, then Save.
5. Wait for GitHub Pages to publish and open the URL shown on the Pages screen.

## Important limitation
The checker is a simple rule-based educational demo. It is not connected to an AI model, bank, police, or threat-intelligence database. It can miss scams and can flag legitimate messages. Do not paste passwords, OTPs, or private information.
